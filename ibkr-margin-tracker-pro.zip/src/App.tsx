import React from 'react';
import IBKRMarginTracker from './ibkr-margin-tracker';

function App() {
  return (
    <div className="App">
      <IBKRMarginTracker />
    </div>
  );
}

export default App;